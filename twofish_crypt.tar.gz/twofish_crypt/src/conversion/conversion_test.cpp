#include "conversion_api.h"
#include <ctime>
#include <cstdlib>
#include <stdio.h> //use c lib for fun

struct testResult{
    bool result; //true for passed the false for failed the test
    const char* testname[64]; //64 charactar max for test names
};

void printResult(testResult* tr){
    printf("test ");
    if(tr->result){
        printf("passed : ");
    } else {
        printf("failed : ");
    }
    printf("%s", *(tr->testname));
    printf("\n");
}


//test that conversion and reverting gets same results
bool test_conversion_and_reverting(testResult* tr){
    tr->testname[0] = "conversion and reverting";
    tr->result = true;

    conversion::BYTE buffer[4];

    srand(time(0));

    int original_int;
    int reverted_int;

    //run the test for 5 different numbers to account for palindromes
    for(int i = 0; i < 5; i++){

        original_int = rand();

        conversion::int2byte(&buffer[0], original_int);
        reverted_int = conversion::byte2int(&buffer[0]);

        if (reverted_int != original_int){
            tr->result = false;
            // originally the function was void test_conversion_and_reverting(testResult* tr)
            // but can not return void in c++ to break the function, compiler won't let me
            return false;
        }
    }
    return true;
}

int main(){
    printf("==========testing int2byte_api==========\n");
    testResult tr;
    test_conversion_and_reverting(&tr);
    printResult(&tr);
}
