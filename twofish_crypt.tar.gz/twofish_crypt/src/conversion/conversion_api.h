#ifndef INT_2_BYTE_H_
#define INT_2_BYTE_H_

namespace conversion {

    typedef unsigned char BYTE; //this is put inside the namespace to make everything modular and avoid
                            //collisions

/***************************************************************************************************
*
* Function Name: int2byte
*
* Function:      converts an int into an array of bytes
*
* Arguments:     location = ptr to where the converted in should place the bytes
*                x = the integer that is to be converted into bytes
*
* Return:        void
*
* Notes:         currently, typically an int is 4 bytes long, this may change in the future though
*                if it changes then this function breaks
*
***************************************************************************************************/
    void int2byte(BYTE* location, int x);

/***************************************************************************************************
*
* Function Name: int2byte_stack
*
* Function:      converts an int into an array of bytes
*
* Arguments:     bytes = ptr to where the bytes are to be converted into an int
*
* Return:        the integer that was converted from the bytes
*
* Notes:         currently, typically an int is 4 bytes long, this may change in the future though
*                if it changes then this function breaks
*
***************************************************************************************************/
    int byte2int(BYTE* bytes);

}
#endif
