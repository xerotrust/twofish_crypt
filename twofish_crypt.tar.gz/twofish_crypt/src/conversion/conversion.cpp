#include "conversion_api.h"

namespace conversion {

    void int2byte(BYTE* location, int x){
        *location = (BYTE)(( x >> 24 ) & 0xFF);
        *(location+1) = (BYTE)(( x >> 16 ) & 0xFF);
        *(location+2) = (BYTE)(( x >> 8 ) & 0xFF);
        *(location+3) =  (BYTE)(x & 0xFF);
    }

    int byte2int(BYTE* charstart){
        int x = 0;
        x ^=  *charstart; x <<= 8;
        x ^= *(charstart+1); x <<= 8;
        x ^= *(charstart+2); x <<= 8;
        x ^= *(charstart+3);
        return x;
    }

/* deprecated too many opeations
    int byte2int(BYTE* charstart){
        int x = 0;
        x+= (*charstart)*256*256*256;
        x+= (*(charstart+1))*256*256;
        x+= (*(charstart+2))*256;
        x+= (*(charstart+3));
        return x;
    }
*/
}
