#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "aes.h"

const char hex[16] = {0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x41,0x42,0x43,0x44,0x45,0x46};

typedef struct {
    int passed;
    char* testname[64];
} testResult;


void int2byte(BYTE* location, int x){
        *location = (BYTE)(( x >> 24 ) & 0xFF);
        *(location+1) = (BYTE)(( x >> 16 ) & 0xFF);
        *(location+2) = (BYTE)(( x >> 8 ) & 0xFF);
        *(location+3) =  (BYTE)(x & 0xFF);
}

void printReKeyResult(int i){
    if (i == BAD_KEY_INSTANCE){printf("BAD_KEY_INSTANCE");}
    if (i == BAD_ALIGN32){printf("BAD_ALIGN32");}
    if (i == TRUE){printf("SUCCESS");}
}

int makeRandomKey(keyInstance* ki, int size_bits,char* keyMaterial){
    int result = makeKey(ki, DIR_ENCRYPT, size_bits, keyMaterial);
    reKey(ki);
    return result;
}


void printMakeResult(int i){
    if (i == BAD_KEY_INSTANCE){printf("BAD_KEY_INSTANCE");}
    if (i == BAD_KEY_DIR){printf("BAD_KEY_DIR");}
    if (i == BAD_KEY_INSTANCE){printf("BAD_KEY_MAT");}
    if (i == BAD_ALIGN32){printf("BAD_ALIGN32");}
    if (i == TRUE){printf("KEY MATERIAL IS NULL OR REKEY SUCCESSFUL");}
}

int compareBlocks(BYTE* A, BYTE* B){
    for(int i =0; i < BLOCK_SIZE/8; i++){
        if( *(A+i) != *(B+i) ){
            return 0;
        }
    }
    return 1;
}

void randomKeyMaterial(char* keyBuffer, int size){
    for(int i=0; i < size; i++){
        int h = rand()%16;
        printf("%d ", h);
        *(keyBuffer+i) = hex[h];
    }
    printf("\n");
}

void printBlock(char* title, BYTE* block, int size){
    printf("%s", title);
    printf(" block is : ");
    for(int i = 0; i < size; i++){
        printf("%02hhx ", *(block +i));
    }
    printf("\n");
}

int testkey(int keySizeInBits, testResult* tr, char* keybuffer, char* keybuffer2, cipherInstance* ci,  BYTE* plainText, BYTE* cipherText, BYTE* decryptText,BYTE* wrongText){
    printf("====================================Testing for key size ");
    printf("%d====================================", keySizeInBits);
    printf("\n");
    /*
    You have to be careful with the key material... if you use binary data as input, the twofish
    engine will fail to parse the bytes correctly and will assume the key was 0 0 0 0 0 0....
    this will encrypt and decrypt "correctly" but your algorithm will only have one key...
    very INSECURE!! also to avoid memory sasfety issues the hex representation '4F' takes up
    16 bytes but represnts 1byte of data, the twofish algorith for making a key takes passwords
    as hex representation of a 256bit password takes up 512bytes of space note the difference
    .. it only accepts characters 0..9 a..f and A..F
    the hexadecimal representation of a byte....
    */
    keyInstance ki,wk;
    randomKeyMaterial(keybuffer, keySizeInBits/4);
    printBlock("rightKeyBlock",(BYTE*)keybuffer,keySizeInBits/4);
    makeRandomKey(&ki,keySizeInBits,keybuffer);

    //wrong key
    int randKeySize = 128 + 64*(rand() % 3);
    randomKeyMaterial(keybuffer2, randKeySize/4);
    printBlock("wrongKeyBlock",(BYTE*)keybuffer2,randKeySize/4);
    makeRandomKey(&wk, randKeySize, keybuffer2);

    blockEncrypt(ci, &ki, plainText, BLOCK_SIZE, cipherText);
    printBlock("cipherText",cipherText,BLOCK_SIZE/8);
    blockDecrypt(ci, &ki, cipherText,BLOCK_SIZE, decryptText);
    printBlock("decryptText",decryptText,BLOCK_SIZE/8);
    blockDecrypt(ci, &wk, cipherText,BLOCK_SIZE, wrongText);
    printBlock("wrongText",wrongText,BLOCK_SIZE/8);
    printf("test that the decrypted text is the same as the original text for the right key : ");
    if(compareBlocks(plainText,decryptText) == 1) {
        printf("passed\n");
    } else {
        printf("failed\n");
    }

    printf("test that the decrypted text is *NOT* the same as the original text for the wrong key : ");
    if(compareBlocks(plainText,wrongText) == 0) {
        printf("passed\n");
    } else {
        printf("failed\n");
    }
    printf("\n");
    return 0;
}

void getRandomBlock(BYTE* block){
    for(int i = 0; i < 4; i++){
        int2byte(block+4*i,rand());
    }
}

int main(){
    srand(time(0));
    char keyBuffer2[64];
    char keyBuffer[64];
    BYTE plainText[BLOCK_SIZE/8];
    BYTE cipherText[BLOCK_SIZE/8];
    BYTE decrypted[BLOCK_SIZE/8];
    BYTE wrongText[BLOCK_SIZE/8];

    getRandomBlock(&plainText[0]);

    printBlock("plainText",&plainText[0],BLOCK_SIZE/8);

    cipherInstance ci;
    cipherInit(&ci, MODE_ECB, NULL);

    testResult tr;

    testkey(128,&tr,&keyBuffer[0],&keyBuffer2[0],&ci, &plainText[0], &cipherText[0],&decrypted[0],&wrongText[0]);
    testkey(192,&tr,&keyBuffer[0],&keyBuffer2[0],&ci, &plainText[0], &cipherText[0],&decrypted[0],&wrongText[0]);
    testkey(256,&tr,&keyBuffer[0],&keyBuffer2[0],&ci, &plainText[0], &cipherText[0],&decrypted[0],&wrongText[0]);
}
