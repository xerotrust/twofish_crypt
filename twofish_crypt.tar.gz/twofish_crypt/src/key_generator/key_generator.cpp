#include "../twofish_original/aes.h"
#include "key_generator_api.h"

namespace key_generator{

    void keyInstanceChain::getKeyInstance(keyInstance* ki){
        *ki = this->keyArray[this->index];
        if(this->index < this->numberOfKeys - 1){
            this->index++;
        } else {
            this->index = 0;
        }
    }

    void printMakeResult(int i){
        if (i == BAD_KEY_INSTANCE){printf("BAD_KEY_INSTANCE");}
        if (i == BAD_KEY_DIR){printf("BAD_KEY_DIR");}
        if (i == BAD_KEY_INSTANCE){printf("BAD_KEY_MAT");}
        if (i == BAD_ALIGN32){printf("BAD_ALIGN32");}
        if (i == TRUE){printf("KEY MATERIAL IS NULL OR REKEY IS SUCCESSFUL");}
    }


    void _deepCopy(char* fromArray, char* toArray, int arraySize){
        for(int i = 0; i < arraySize; i++){
            *(toArray+i) = *(fromArray+i);
        }
    }
    //warning keyMaterial must be hex only remember that...it got checked at the command line interface
    //key size bits should have been loaded
    int loadKeyIntoMemory(char* keyMaterial, int key_size_bits, keyInstanceChain* kic,BYTE DIR){
        int number_of_256_bit_keys = key_size_bits / 256;
        int last_key_size_raw = key_size_bits % 256;
        int last_key_size_padded;

        if (last_key_size_raw <= 128){
            last_key_size_padded = 128;
        } else if (last_key_size_raw <=192){
            last_key_size_padded = 192;
        } else {
            last_key_size_padded = 256;
        }

        int total_number_of_keys = number_of_256_bit_keys;

        if(last_key_size_raw != 0){
            total_number_of_keys++;
        }

        char keyMaterialBuffer[64];
        int keyIndex = 0;
        keyInstance ki;
        int makeKeyResult;

        for(int i = 0; i < number_of_256_bit_keys; i++){
            _deepCopy(keyMaterial+keyIndex, &keyMaterialBuffer[0],64);
            makeKeyResult = makeKey(&ki, DIR, 256, &keyMaterialBuffer[0]);
            if(makeKeyResult!=TRUE){
                printMakeResult(makeKeyResult);
                return 1; //break out of this function
            }
            kic->keyArray[i] = ki;
            keyIndex+=32;
        }

        if(last_key_size_raw !=0){
            _deepCopy(keyMaterial+keyIndex, &keyMaterial[0],last_key_size_raw/4);
            for(int i = last_key_size_raw/4; i < last_key_size_padded/4; i++){
                keyMaterialBuffer[i] = 0x30; //pad with zeros
            }
            makeKeyResult = makeKey(&ki, DIR, last_key_size_padded, &keyMaterialBuffer[0]);
            if(makeKeyResult!=TRUE){
                printMakeResult(makeKeyResult);
                return 1; //break out of this function
            }
            kic->keyArray[total_number_of_keys-1] = ki;

        }

        kic->index = 0;
        kic->numberOfKeys = total_number_of_keys;

        return 0;
    }
}
