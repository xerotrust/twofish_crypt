#include "../twofish_original/aes.h"
#include "key_generator_api.h"
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <cstring>

const char hex[16] = {0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x41,0x42,0x43,0x44,0x45,0x46};

int main(){
    char keyBuffer[2048];

    srand(time(0));
    int numberOfBits = 8 * (1+(rand() % 1024));
    int keyLen_ascii = numberOfBits/4;

    for(int i = 0; i < keyLen_ascii; i++){
        keyBuffer[i] = hex[rand()%16];
    }

    key_generator::keyInstanceChain kic;

    int result = key_generator::loadKeyIntoMemory(&keyBuffer[0], numberOfBits, &kic, DIR_ENCRYPT);


    std::cout << "testing that all the keys were made successfully: ";
    if(result == 0){
        std::cout << "passed";
    } else {
        std::cout << "failed";
    }
    std::cout<<std::endl;

    int numberOfKeys = (numberOfBits)/256;
    if (numberOfBits % 256 > 0){
        numberOfKeys++;
    }

    std::cout << "testing that correct number of keys were made : ";
    if (kic.numberOfKeys == numberOfKeys){
        std::cout << "passed";
    } else {
        std::cout << "failed";
    }
    std::cout<<std::endl;
}
