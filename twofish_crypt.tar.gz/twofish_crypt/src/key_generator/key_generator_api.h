#ifndef KEY_GENERATOR_API_H_
#define KEY_GENERATOR_API_H_

#include "../twofish_original/aes.h"

namespace key_generator{
    class keyInstanceChain {
    public:
        int numberOfKeys;
        int index;
        keyInstance keyArray[32]; // max of 32

/***************************************************************************************************
*
* Function Name: getKeyInstance
*
* Function:      gets a keyInstance
*
* Arguments:     ki a pointer to a keyInstance
*
* Return:        void
*
* Notes:         (none)
*
***************************************************************************************************/
        void getKeyInstance(keyInstance* ki);
    };

/***************************************************************************************************
*
* Function Name: loadKeyIntoMemory
*
* Function:      converts a ascii-hex password into a key object that the twofish engine knows how
*                to use
*
* Arguments:     keyMaterial - a ascii-hex char array of up to 2048 characters long representing
                 1024 bytes or 8192 bits
*
* Return:        the integer that designates whether or not the key objects were successfully
*                created
*
* Notes:         (none)
*
***************************************************************************************************/
    int loadKeyIntoMemory(char* keyMaterial, int key_size_bits, keyInstanceChain* kic, BYTE DIR);
}
#endif
