/*This is a command line tool that takes the following arguments
 * fcrypt [OPTIONS] [KEY FILE] [INPUT FILE] [OUTPUT FILE] */
#include <iostream>
#include <fstream>
#include <cstring>
#include "../file_encryption/file_encryption_api.h"
const char eflag [3] = {'-','e','\0'};
const char dflag [3] = {'-','d','\0'};

void command_line_help(){
    printf("this is a command line tool that encrypts files using the twofish algorithm\n");
    printf("tfcrypt [OPTIONS] [KEY FILE] [INPUT FILE] [OUTPUT FILE] is the usage\n");
    printf("OPTIONS is either -e for encrypt or -d for decrypt\n");
}

int main(int argc, char* argv[]){

    if(argc != 5){ // there are 4 arguments but argv[0] is always the invocation
        command_line_help();

    } else {
        int e_compare = strcmp(&eflag[0],argv[1]);
        int d_compare = strcmp(&dflag[0],argv[1]);

        if ( e_compare != 0 && d_compare != 0){
            command_line_help();
        } else {
            //variable setup
            std::ifstream keyfile;
            std::ifstream inputfile;
            std::ofstream outputfile;

            //load key file
            keyfile.open(argv[2],std::ifstream::ate | std::ifstream::binary);
            if(!keyfile.is_open()){
                std::cout << "The key file \"" << argv[2] << "\" does not exist" << std::endl;
                return 1;
            }

            //loadInput file
            inputfile.open(argv[3],std::ifstream::ate | std::ifstream::binary);
            if(! inputfile.is_open()){
                std::cout << "The input file \"" << argv[3] << "\" does not exist" << std::endl;
                return 1;
            }

            //open outputfile
            outputfile.open(argv[4], std::ofstream::binary);
            if(! outputfile.is_open()){
                std::cout << "The output file \"" << argv[4] << "\" could not be created"
                << std::endl;
                return 1;
            }

            if(e_compare == 0){
                std::cout << "encrypting\n";
                file_encryption::encryptFile(&keyfile, &inputfile, &outputfile);
            }

            if(d_compare == 0){
                std::cout << "decrypting\n";
                file_encryption::decryptFile(&keyfile, &inputfile, &outputfile);
            }
            inputfile.close();
            outputfile.flush();
            outputfile.close();
        }
    }
    return 0;
}
