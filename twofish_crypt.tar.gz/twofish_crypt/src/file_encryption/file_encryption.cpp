#include "../constants.h"
#include "../conversion/conversion_api.h"
#include "../key_generator/key_generator_api.h"
#include "../twofish_original/aes.h"
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <fstream>

namespace file_encryption {

    const int BLOCK_SIZE_BYTES = BLOCK_SIZE/8;
    const int MAX_ASCII_HEX_KEY = 2048;

    void _encryptBlock(cipherInstance* ci, keyInstance* ki, BYTE* inputBlock, BYTE* outputBlock){
        //DEFINE THE ENCRYPTION ALGORYTHM HERE
        blockEncrypt(ci, ki, inputBlock, BLOCK_SIZE, outputBlock);
    }

    void _decryptBlock(cipherInstance* ci, keyInstance* ki, BYTE* inputBlock, BYTE* outputBlock){
        //DEFINE THE DECRYPTION ALGORYTHM HERE
        blockDecrypt(ci, ki, inputBlock, BLOCK_SIZE, outputBlock);
    }

    void printBlock(BYTE* block){
        for(int i = 0; i < BLOCK_SIZE_BYTES; i++){
            std::cout << (int)*(block+i);
        }
        std::cout << std::endl;
    }

    void _exclusiveOr(BYTE* chainBlock, BYTE * writeBlock){
        for(int i = 0; i < BLOCK_SIZE_BYTES; i++){
            *(writeBlock+i) ^= *(chainBlock+i);
        }
    }

    void _deepCopy(BYTE* fromArray, BYTE* toArray, int arraySize){
        for(int i = 0; i < arraySize; i++){
            *(toArray+i) = *(fromArray+i);
        }
    }

    void _encryptChain(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock, BYTE* writeBlock,
    BYTE* loadBlock, std::ofstream* outputfile){
        _exclusiveOr(chainBlock,loadBlock);
        _encryptBlock(ci, ki ,loadBlock, writeBlock); //this for some reason is not encrypting into the writeblock thats the issue
        outputfile->write((const char*)writeBlock,BLOCK_SIZE_BYTES);
        _deepCopy(writeBlock,chainBlock,BLOCK_SIZE_BYTES);
    }

    void _decryptChain(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock,
    BYTE* writeBlock,BYTE* loadBlock, std::ofstream* outputfile){
        _decryptBlock(ci, ki ,loadBlock, writeBlock);
        _exclusiveOr(chainBlock,writeBlock);
        outputfile->write((const char*)writeBlock,BLOCK_SIZE_BYTES);
        _deepCopy(loadBlock,chainBlock,BLOCK_SIZE_BYTES);
    }

    void _encryptIV(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock, BYTE* writeBlock,
    BYTE* loadBlock, std::ofstream* outputfile){
	    //Set the block chain to the iv this block is chained a little bit differently
        for(int i = 0; i < 4; i++){
            conversion::int2byte(chainBlock + 4*i, rand());
        }
        _encryptBlock(ci, ki, chainBlock, writeBlock);
        outputfile->write((const char*)writeBlock,BLOCK_SIZE_BYTES);
    }

    void _decryptIV(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock, BYTE* writeBlock,
    BYTE* loadBlock){
        _decryptBlock(ci, ki, loadBlock,chainBlock);
    }

    void _encryptSizeBlock(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock, BYTE* writeBlock, BYTE* loadBlock,
    std::ofstream* outputfile, int pad_size){
        //first fill the block with random numbers
        for(int i = 0; i < 4; i++){
            conversion::int2byte(loadBlock + 4*i, rand());
        }
        *loadBlock = (BYTE)pad_size; //store the size of the padding in the first byte spot of the size chainBlock
        _encryptChain(ci, ki, chainBlock, writeBlock, loadBlock, outputfile);
    }

    void _decryptSizeBlock(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock, BYTE* writeBlock,
    BYTE* loadBlock){
        _decryptBlock(ci, ki, loadBlock, writeBlock);
        _exclusiveOr(chainBlock, writeBlock);
        _deepCopy(loadBlock, chainBlock, BLOCK_SIZE_BYTES);
    }

    void _encryptPadBlock(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock, BYTE* writeBlock,
    BYTE* loadBlock, std::ifstream* inputfile, std::ofstream* outputfile, int pad_size){
        //fill the load block with random bits
        for(int i = 0; i < BLOCK_SIZE_BYTES/sizeof(int); i++){
            conversion::int2byte(loadBlock + 4*i, rand());
        }
        for(int i = pad_size; i < BLOCK_SIZE_BYTES; i++){
            inputfile->read((char*)(loadBlock+i),1);
        }


        _encryptChain(ci, ki, chainBlock, writeBlock, loadBlock, outputfile);
    }

    void _decryptPadBlock(cipherInstance* ci, keyInstance* ki, BYTE* chainBlock, BYTE* writeBlock,
    BYTE* loadBlock, std::ofstream* outputfile, int pad_size){
        _decryptBlock(ci, ki, loadBlock, writeBlock);
        _exclusiveOr(chainBlock, writeBlock);
        _deepCopy(loadBlock,chainBlock, BLOCK_SIZE_BYTES);
        for(int i = pad_size; i < BLOCK_SIZE_BYTES; i ++){
            outputfile->write((char*)(writeBlock+i), 1);
        }
    }



    void encryptFile(std::ifstream* keyFile, std::ifstream* inputfile, std::ofstream* outputfile){

        //Initialize values


        BYTE chainBlock[BLOCK_SIZE_BYTES];
	    BYTE writeBlock[BLOCK_SIZE_BYTES];
	    BYTE loadBlock[BLOCK_SIZE_BYTES];
	    char keyMaterial[MAX_ASCII_HEX_KEY];

	    keyInstance ki;

        cipherInstance ci;
        cipherInit(&ci, MODE_ECB, NULL);

	    key_generator::keyInstanceChain kic;

	    std::ifstream::pos_type key_size_raw = keyFile->tellg();
        keyFile->seekg(0,std::ios::beg);

	    int key_size;

	    if( key_size_raw > MAX_ASCII_HEX_KEY){
	        key_size = 8192;
	    } else {
	        key_size = key_size_raw*4;
	    }

        keyFile->read(&keyMaterial[0], key_size/4);

        key_generator::loadKeyIntoMemory(&keyMaterial[0], key_size, &kic,DIR_ENCRYPT);


        std::ifstream::pos_type input_file_size = inputfile->tellg();
        inputfile->seekg(0,std::ios::beg);

        int extra_bytes = (int)input_file_size % ((int)BLOCK_SIZE_BYTES);
        int pad_size;
        if(extra_bytes == 0){
            pad_size = 0;
        } else {
            pad_size = BLOCK_SIZE_BYTES - extra_bytes;
        }
        int rounds = ((int)input_file_size)/((int)BLOCK_SIZE_BYTES);

        //Encrypt the IV
        kic.getKeyInstance(&ki);
        _encryptIV(&ci, &ki, &chainBlock[0], &writeBlock[0], &loadBlock[0], outputfile);
        //Encrypt the block containing the metadata
        kic.getKeyInstance(&ki);
        _encryptSizeBlock(&ci, &ki, &chainBlock[0], &writeBlock[0], &loadBlock[0], outputfile,
        pad_size);
        //Encrypt the first block if it contains padding
        if(pad_size != 0){
            kic.getKeyInstance(&ki);
            _encryptPadBlock(&ci, &ki, &chainBlock[0], &writeBlock[0], &loadBlock[0], inputfile,
            outputfile, pad_size);
        }

        //Encrypt all the regular blocks
        for(int i = 0; i < rounds; i++){
            kic.getKeyInstance(&ki);
            inputfile->read((char*)&loadBlock[0], BLOCK_SIZE_BYTES);
            _encryptChain( &ci, &ki, &chainBlock[0], &writeBlock[0], &loadBlock[0],
            outputfile);
        }
    }

    void load(std::ifstream* inputfile, BYTE* block){
        for(int i = 0; i < BLOCK_SIZE_BYTES; i++){
            inputfile->read((char*)(block+i),1);
        }
    }

    void decryptFile(std::ifstream* keyFile, std::ifstream* inputfile, std::ofstream* outputfile){
        //Initialize values


        BYTE chainBlock[BLOCK_SIZE_BYTES];
	    BYTE writeBlock[BLOCK_SIZE_BYTES];
	    BYTE loadBlock[BLOCK_SIZE_BYTES];
	    char keyMaterial[MAX_ASCII_HEX_KEY];

	    cipherInstance ci;
	    cipherInit(&ci, MODE_ECB,NULL);

	    keyInstance ki;

	    key_generator::keyInstanceChain kic;

	    int key_size_raw =  (int)keyFile->tellg();
        keyFile->seekg(0,std::ios::beg);

	    int key_size;
	    if( key_size_raw > MAX_ASCII_HEX_KEY){
	        key_size = 8192;
	    } else {
	        key_size = key_size_raw*4;
	    }

	    keyFile->read(&keyMaterial[0], key_size/4);
        key_generator::loadKeyIntoMemory(&keyMaterial[0], key_size, &kic, DIR_ENCRYPT);

        int pad_size;

        std::ifstream::pos_type input_file_size = inputfile->tellg();
        inputfile->seekg(0,std::ios::beg);

        int rounds;

        //decrypt the IV
        kic.getKeyInstance(&ki);
        inputfile->read((char*)&loadBlock[0], BLOCK_SIZE_BYTES);
        _decryptIV(&ci, &ki, chainBlock, writeBlock, loadBlock);

        //decrypt the metadata
        kic.getKeyInstance(&ki);
        inputfile->read((char*)&loadBlock[0], BLOCK_SIZE_BYTES);
        _decryptSizeBlock(&ci, &ki, chainBlock, writeBlock, loadBlock);

        pad_size= (int)writeBlock[0];
        rounds = ((int)input_file_size - 2*BLOCK_SIZE_BYTES)/((int)BLOCK_SIZE_BYTES);
        if(pad_size != 0){
            rounds--;
        }
        if (pad_size < 0 || pad_size > (BLOCK_SIZE-1)){
            pad_size = 0;
        }

        //decrypt the padded block if any
        if(pad_size != 0){
            kic.getKeyInstance(&ki);
            inputfile->read((char*)&loadBlock[0], BLOCK_SIZE_BYTES);
            _decryptPadBlock(&ci, &ki, &chainBlock[0], &writeBlock[0], &loadBlock[0], outputfile,
            pad_size);
        }

        //decrypt the regular blocks
        for(int i = 0; i < rounds; i++){
            kic.getKeyInstance(&ki);
            inputfile->read((char*)(&loadBlock[0]), BLOCK_SIZE_BYTES);
            _decryptChain(&ci, &ki, &chainBlock[0], &writeBlock[0], &loadBlock[0], outputfile);
        }
    }
}
