#ifndef TF_FILE_ENCRYPTION_API_H_
#define TF_FILE_ENCRYPTION_API_H_
#include <iostream>
#include <fstream>

namespace file_encryption{
/***************************************************************************************************
*
* Function Name: encryptFile
*
* Function:      encrypts a file
*
* Arguments:     keyFile - the keyFile represented as a stream
*                inputfile - the input file represented as a stream
*                outputfile - the output file represented as a stream
*
* Return:        int returns 1 if encryption failed for whatever reason, and 0 for success
*
* Notes:         (none)
*
***************************************************************************************************/
    int encryptFile(std::ifstream* keyFile, std::ifstream* inputfile, std::ofstream* outputfile);

/***************************************************************************************************
*
* Function Name: decryptFile
*
* Function:      decrypts a file
*
* Arguments:     keyFile - the keyFile represented as a stream
*                inputfile - the input file represented as a stream
*                outputfile - the output file represented as a stream
*
* Return:        int returns 1 if encryption failed for whatever reason, and 0 for success
*
* Notes:         (none)
*
***************************************************************************************************/
    int decryptFile(std::ifstream* keyFile, std::ifstream* inputfile, std::ofstream* outputfile);
}

#endif
