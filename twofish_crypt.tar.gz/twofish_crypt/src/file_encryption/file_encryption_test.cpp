#include "file_encryption_api.h"
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <cstdio>

const char hex[16] = {0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x41,0x42,0x43,0x44,0x45,0x46};

void int2char(char* location, int x){
        *location = (char)(( x >> 24 ) & 0xFF);
        *(location+1) = (char)(( x >> 16 ) & 0xFF);
        *(location+2) = (char)(( x >> 8 ) & 0xFF);
        *(location+3) =  (char)(x & 0xFF);
}

void getRandomKey(char* keyBuffer, int keySizeInBits){
    int keySizeInBytes = keySizeInBits/8;
    int keySizeInHex_Bytes = keySizeInBytes*2;
    for(int i = 0; i < keySizeInHex_Bytes; i++);
}

void generateKeys(char* rightFileName, char* wrongFileName){
    std::ofstream outputfile;
    int size;

    outputfile.open(rightFileName, std::ofstream::binary);
    size = ((1 + (rand()%8192))/8)*2;
    for (int i = 0; i < size; i++){
        outputfile.write(&hex[rand()%16],1);
    }
    outputfile.flush();
    outputfile.close();

    outputfile.open(wrongFileName, std::ofstream::binary);
    size = ((1 + (rand()%8192))/8)*2;
    for (int i = 0; i < size; i++){
        outputfile.write(&hex[rand()%16],1);
    }

    outputfile.flush();
    outputfile.close();
}

void generateRandomOriginalFile(char* originalFileName){
    std::ofstream outputfile;
    int size;

    outputfile.open(originalFileName, std::ofstream::binary);
    size = rand() % 2048; //this is going to be how many ints (4bytes there are in the file)

    char l;

    for(int i = 0; i < size; i++){
        l= (char)rand()%256;
        outputfile.write(&l,1);
    }
    outputfile.flush();
    outputfile.close();
}

void encryptFile(char* keyFileName, char* originalFileName, char* encryptedFileName){
    std::ifstream keyfile;
    std::ifstream inputfile;
    std::ofstream outputfile;

    keyfile.open(keyFileName, std::ifstream::ate | std::ifstream::binary);
    inputfile.open(originalFileName, std::ifstream::ate | std::ifstream::binary);
    outputfile.open(encryptedFileName, std::ofstream::binary);

    file_encryption::encryptFile(&keyfile, &inputfile, &outputfile);

    keyfile.close();
    inputfile.close();
    outputfile.flush();
    outputfile.close();
}

void decryptFile(char* keyFileName, char* encryptedFileName, char* decryptedFileName){
    std::ifstream keyfile;
    std::ifstream inputfile;
    std::ofstream outputfile;

    keyfile.open(keyFileName, std::ifstream::ate | std::ifstream::binary);
    inputfile.open(encryptedFileName, std::ifstream::ate | std::ifstream::binary);
    outputfile.open(decryptedFileName, std::ofstream::binary);

    file_encryption::decryptFile(&keyfile, &inputfile, &outputfile);

    keyfile.close();
    inputfile.close();
    outputfile.flush();
    outputfile.close();
}

int check_original_file_and_decrypted_file_are_same(char* originalFileName, char* decryptedFileName){
    std::cout << "Check that the original and decrypted file are the same : ";

    std::ifstream originalFile;
    std::ifstream decryptedFile;

    originalFile.open(originalFileName, std::ifstream::ate | std::ifstream::binary);
    decryptedFile.open(decryptedFileName, std::ifstream::ate | std::ifstream::binary);

    int o_size = originalFile.tellg();
    int d_size = decryptedFile.tellg();

    originalFile.seekg(0,std::ifstream::beg);
    decryptedFile.seekg(0,std::ifstream::beg);

    if(o_size != d_size){
        std::cout << "fail : file sizes are different" << std::endl;
        return 1;
    } else {
        char readBufferOriginal;
        char readBufferDecrypted;
        for(int i = 0; i < o_size; i++){
            originalFile.read(&readBufferOriginal,1);
            decryptedFile.read(&readBufferDecrypted,1);
            if(readBufferDecrypted != readBufferOriginal){
                std::cout << "original= " << (int)readBufferOriginal << "     decrypted= " << (int)readBufferDecrypted << std::endl;
                std::cout << "fail : different data @" << i << std::endl;
                return 1;
            }
        }
    }
    std::cout << "passed" << std::endl;
    return 0;
}

int check_original_file_and_wrong_file_are_not_same(char* originalFileName, char* wrongFileName){
    std::cout << "Check that the original and wrong file are the same : ";

    std::ifstream originalFile;
    std::ifstream wrongFile;

    originalFile.open(originalFileName, std::ifstream::ate | std::ifstream::binary);
    wrongFile.open(wrongFileName, std::ifstream::ate | std::ifstream::binary);

    int o_size = originalFile.tellg();
    int w_size = wrongFile.tellg();

    originalFile.seekg(0);
    wrongFile.seekg(0);

    if(o_size != w_size){
        std::cout << "passed : file sizes are different" << std::endl;
        return 0;
    } else {
        char readBufferOriginal;
        char readBufferWrong;

        for(int i = 0; i < o_size; i++){
            originalFile.read(&readBufferOriginal,1);
            wrongFile.read(&readBufferWrong,1);
            if(readBufferWrong != readBufferOriginal){
                std::cout << "passed : different data" << std::endl;
                return 0;
            }
        }
    }
    std::cout << "failed" << std::endl;
    return 1;

}

int main(){
    srand(time(0));

    char wrongKeyFileName[16] = "wrongKey_file";
    char rightKeyFileName[16] = "rightKey_file";
    char originalFileName[16] = "original_file";
    char encryptedFileName[16] = "encrypted_file";
    char decryptedFileName[16] = "decrypted_file";
    char wrongFileName[16] = "wrong_file";

    generateKeys(&rightKeyFileName[0], &wrongKeyFileName[0]);
    generateRandomOriginalFile(&originalFileName[0]);

    encryptFile(&rightKeyFileName[0], &originalFileName[0], &encryptedFileName[0]);
    decryptFile(&rightKeyFileName[0], &encryptedFileName[0], &decryptedFileName[0]);
    decryptFile(&wrongKeyFileName[0], &encryptedFileName[0], &wrongFileName[0]);

    check_original_file_and_decrypted_file_are_same(&originalFileName[0], &decryptedFileName[0]);
    check_original_file_and_wrong_file_are_not_same(&originalFileName[0], &wrongFileName[0]);

    remove(&rightKeyFileName[0]);
    remove(&wrongKeyFileName[0]);
    remove(&originalFileName[0]);
    remove(&encryptedFileName[0]);
    remove(&decryptedFileName[0]);
    remove(&wrongFileName[0]);
}
